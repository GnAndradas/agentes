import type { FastifyInstance } from 'fastify';
import * as h from './handlers.js';
import * as state from '../taskState/handlers.js';

export async function taskRoutes(fastify: FastifyInstance) {
  fastify.get('/', h.list);
  fastify.get('/pending', h.getPending);
  fastify.get('/running', h.getRunning);
  fastify.get('/:id', h.get);
  fastify.get('/:id/subtasks', h.getSubtasks);
  fastify.post('/', h.create);
  fastify.patch('/:id', h.update);
  fastify.delete('/:id', h.remove);
  fastify.post('/:id/assign', h.assign);
  fastify.post('/:id/queue', h.queue);
  fastify.post('/:id/start', h.start);
  fastify.post('/:id/complete', h.complete);
  fastify.post('/:id/fail', h.fail);
  fastify.post('/:id/cancel', h.cancel);
  fastify.post('/:id/retry', h.retry);

  // BLOQUE 11: Diagnostics endpoints
  fastify.get('/:id/diagnostics', h.getDiagnostics);
  fastify.get('/:id/timeline', h.getTimeline);

  // DECISION TRACEABILITY: Why task was/wasn't assigned
  fastify.get('/:id/decision-trace', h.getDecisionTrace);
  fastify.get('/decision-trace/stats', h.getDecisionTraceStats);

  // TASK STATE: Execution state endpoints
  fastify.get('/:id/state', state.getTaskState);
  fastify.get('/:id/state/snapshot', state.getTaskStateSnapshot);
  fastify.post('/:id/state/init', state.initTaskState);
  fastify.get('/:id/checkpoints', state.getTaskCheckpoints);
  fastify.post('/:id/checkpoint', state.createCheckpoint);
  fastify.post('/:id/pause', state.pauseTask);
  fastify.post('/:id/resume', state.resumeTask);

  // P0-02: Generation traceability endpoints
  fastify.get('/:id/generation-trace', h.getGenerationTrace);
  fastify.get('/:id/generation-trace/history', h.getGenerationTraceHistory);
}
