import { useQuery } from '@tanstack/react-query';
import {
  Wifi,
  WifiOff,
  Server,
  ServerOff,
  Activity,
  ChevronUp,
  ChevronDown,
  Loader2,
  CheckCircle2,
  XCircle,
  Trash2,
  Cpu,
  Terminal,
  Zap,
  Link,
  Link2Off,
  HelpCircle,
} from 'lucide-react';
import { systemApi, type QuickStatus, type HealthResponse } from '../../lib/api';
import { useAppStore, type StatusActivity } from '../../stores/app';

// Type guards for union types
type HealthError = { error: string; status: null };
type GatewayError = { error: string };

function isHealthResponse(data: HealthResponse | HealthError | undefined): data is HealthResponse {
  return !!data && !('error' in data);
}

function isQuickStatus(data: QuickStatus | GatewayError | undefined): data is QuickStatus {
  return !!data && 'rest' in data;
}

const activityIcons = {
  gateway: Server,
  generation: Cpu,
  task: Activity,
  approval: CheckCircle2,
  sync: Loader2,
};

const statusColors = {
  pending: 'text-yellow-400',
  running: 'text-blue-400',
  success: 'text-green-400',
  error: 'text-red-400',
};

function ActivityItem({ activity }: { activity: StatusActivity }) {
  const Icon = activityIcons[activity.type] || Activity;
  const colorClass = statusColors[activity.status];
  const isRunning = activity.status === 'running' || activity.status === 'pending';
  const timeAgo = Math.floor((Date.now() - activity.timestamp) / 1000);
  const timeStr = timeAgo < 60 ? `${timeAgo}s` : `${Math.floor(timeAgo / 60)}m`;

  return (
    <div className="flex items-center gap-2 px-2 py-1 text-xs hover:bg-dark-800 rounded">
      <Icon className={`w-3 h-3 ${colorClass} ${isRunning ? 'animate-pulse' : ''}`} />
      <span className="flex-1 truncate text-dark-300">{activity.message}</span>
      <span className="text-dark-500">{timeStr}</span>
      {activity.status === 'running' && (
        <Loader2 className="w-3 h-3 animate-spin text-blue-400" />
      )}
      {activity.status === 'success' && (
        <CheckCircle2 className="w-3 h-3 text-green-400" />
      )}
      {activity.status === 'error' && (
        <XCircle className="w-3 h-3 text-red-400" />
      )}
    </div>
  );
}

export function StatusBar() {
  const {
    connected,
    statusBarVisible,
    toggleStatusBar,
    activities,
    clearActivities,
    setGatewayConnected,
    monitorOpen,
    setMonitorOpen,
  } = useAppStore();

  // Check backend health periodically (OCAAS server) - now returns runtime info
  const { data: backendHealth } = useQuery({
    queryKey: ['system', 'health'],
    queryFn: async () => {
      try {
        return await systemApi.health();
      } catch (err) {
        if (err instanceof TypeError) {
          return { error: 'unreachable', status: null };
        }
        return { error: 'server_error', status: null };
      }
    },
    refetchInterval: 10000, // Every 10 seconds
    retry: false,
  });

  const backendHealthy = isHealthResponse(backendHealth);
  const backendError = !backendHealthy && backendHealth ? (backendHealth as HealthError).error as 'unreachable' | 'server_error' : undefined;
  const backendVersion = backendHealthy ? backendHealth.version : undefined;
  const backendUptime = backendHealthy ? backendHealth.uptime : undefined;
  const backendEnv = backendHealthy ? backendHealth.environment : undefined;
  const backendCommit = backendHealthy ? backendHealth.commit : undefined;

  // Check gateway status (OpenClaw) - HONEST: makes real requests
  const { data: gatewayStatus } = useQuery({
    queryKey: ['system', 'gateway'],
    queryFn: async () => {
      try {
        const status = await systemApi.gatewayStatus();
        // Update store with REST connection status
        setGatewayConnected(status.rest.reachable && status.rest.authenticated);
        return status;
      } catch (err) {
        setGatewayConnected(false);
        const isNetworkError = err instanceof TypeError && err.message.includes('fetch');
        return { error: isNetworkError ? 'unreachable' : 'server_error' };
      }
    },
    refetchInterval: 10000, // Every 10 seconds
    retry: false,
  });

  // Derive status indicators from QuickStatus (use type guard)
  const gwStatus = isQuickStatus(gatewayStatus) ? gatewayStatus : undefined;
  const gwError = !gwStatus && gatewayStatus ? (gatewayStatus as GatewayError).error : undefined;
  const restOk = gwStatus?.rest?.reachable && gwStatus?.rest?.authenticated;
  const hooksConfigured = gwStatus?.hooks?.configured;
  const hooksProbed = gwStatus?.hooks?.probed;
  const probeEnabled = gwStatus?.probe?.enabled;
  const probeTested = gwStatus?.probe?.tested;
  // OpenClaw WS status available via gatewayStatus?.websocket.connected if needed

  // Get orchestrator status
  const { data: orchestratorData } = useQuery({
    queryKey: ['system', 'orchestrator'],
    queryFn: systemApi.getOrchestrator,
    refetchInterval: 5000,
    retry: false,
  });

  const runningActivities = activities.filter(
    (a) => a.status === 'running' || a.status === 'pending'
  );
  const recentActivities = activities.slice(0, 10);

  return (
    <div className="border-t border-dark-800 bg-dark-900">
      {/* Expandable activity panel */}
      {statusBarVisible && (
        <div className="border-b border-dark-800 max-h-48 overflow-y-auto">
          <div className="flex items-center justify-between px-3 py-1 bg-dark-850">
            <span className="text-xs font-medium text-dark-400">Activity Log</span>
            <button
              onClick={clearActivities}
              className="p-1 hover:bg-dark-700 rounded text-dark-500 hover:text-dark-300"
              title="Clear activities"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
          {recentActivities.length === 0 ? (
            <div className="px-3 py-2 text-xs text-dark-500">No recent activity</div>
          ) : (
            <div className="py-1">
              {recentActivities.map((activity) => (
                <ActivityItem key={activity.id} activity={activity} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Status bar */}
      <div className="flex items-center justify-between px-3 py-1 text-xs">
        <div className="flex items-center gap-4">
          {/* WebSocket connection (OCAAS real-time) */}
          <div className="flex items-center gap-1.5" title="WebSocket connection to OCAAS">
            {connected ? (
              <>
                <Wifi className="w-3.5 h-3.5 text-green-400" />
                <span className="text-dark-400">WS</span>
              </>
            ) : (
              <>
                <WifiOff className="w-3.5 h-3.5 text-red-400" />
                <span className="text-red-400">WS Off</span>
              </>
            )}
          </div>

          {/* Backend health (OCAAS server) */}
          <div
            className="flex items-center gap-1.5"
            title={
              backendHealthy
                ? `OCAAS Backend v${backendVersion || '?'}${backendCommit ? ` (${backendCommit})` : ''}\nUptime: ${backendUptime || '?'}\nEnv: ${backendEnv || '?'}`
                : 'OCAAS Backend disconnected'
            }
          >
            {backendHealthy ? (
              <>
                <Zap className="w-3.5 h-3.5 text-green-400" />
                <span className="text-dark-400">
                  Backend
                  {backendVersion && (
                    <span className="ml-1 text-dark-500 text-[10px]">v{backendVersion}</span>
                  )}
                  {backendCommit && (
                    <span className="ml-1 text-dark-600 text-[10px]">{backendCommit.slice(0, 7)}</span>
                  )}
                </span>
              </>
            ) : (
              <>
                <Zap className="w-3.5 h-3.5 text-red-400" />
                <span className="text-red-400">
                  {backendError === 'unreachable' ? 'Backend Unreachable' : 'Backend Error'}
                </span>
              </>
            )}
          </div>

          {/* OpenClaw REST API */}
          <div
            className="flex items-center gap-1.5"
            title={
              restOk
                ? `OpenClaw REST OK (${gwStatus?.rest?.latencyMs ?? 0}ms)`
                : gwError === 'unreachable'
                  ? 'OpenClaw unreachable (network)'
                  : gwStatus?.rest?.error || 'OpenClaw REST error'
            }
          >
            {restOk ? (
              <>
                <Server className="w-3.5 h-3.5 text-green-400" />
                <span className="text-dark-400">REST</span>
              </>
            ) : (
              <>
                <ServerOff className="w-3.5 h-3.5 text-red-400" />
                <span className="text-red-400">REST Off</span>
              </>
            )}
          </div>

          {/* Hooks status - HONEST: shows configured vs probed */}
          <div
            className="flex items-center gap-1.5"
            title={
              hooksProbed
                ? (gwStatus?.hooks?.working ? 'Hooks working' : 'Hooks failed')
                : hooksConfigured
                  ? 'Hooks configured (not probed)'
                  : 'Hooks not configured'
            }
          >
            {hooksConfigured ? (
              hooksProbed ? (
                gwStatus?.hooks?.working ? (
                  <>
                    <Link className="w-3.5 h-3.5 text-green-400" />
                    <span className="text-dark-400">Hooks</span>
                  </>
                ) : (
                  <>
                    <Link2Off className="w-3.5 h-3.5 text-red-400" />
                    <span className="text-red-400">Hooks Err</span>
                  </>
                )
              ) : (
                <>
                  <HelpCircle className="w-3.5 h-3.5 text-yellow-400" />
                  <span className="text-yellow-400">Hooks ?</span>
                </>
              )
            ) : (
              <>
                <Link2Off className="w-3.5 h-3.5 text-dark-500" />
                <span className="text-dark-500">No Hooks</span>
              </>
            )}
          </div>

          {/* Probe status - HONEST: shows if enabled and tested */}
          {probeEnabled && (
            <div
              className="flex items-center gap-1.5"
              title={
                probeTested
                  ? (gwStatus?.probe?.working ? 'Generation probe OK' : `Probe failed: ${gwStatus?.probe?.error ?? 'unknown'}`)
                  : 'Probe enabled (run diagnostic for full test)'
              }
            >
              {probeTested ? (
                gwStatus?.probe?.working ? (
                  <>
                    <Cpu className="w-3.5 h-3.5 text-green-400" />
                    <span className="text-dark-400">Probe</span>
                  </>
                ) : (
                  <>
                    <Cpu className="w-3.5 h-3.5 text-red-400" />
                    <span className="text-red-400">Probe Err</span>
                  </>
                )
              ) : (
                <>
                  <Cpu className="w-3.5 h-3.5 text-yellow-400" />
                  <span className="text-yellow-400">Probe ?</span>
                </>
              )}
            </div>
          )}

          {/* Orchestrator status */}
          {orchestratorData && (
            <div className="flex items-center gap-1.5" title="Orchestrator">
              <Activity
                className={`w-3.5 h-3.5 ${
                  orchestratorData.running ? 'text-green-400' : 'text-dark-500'
                }`}
              />
              <span className="text-dark-400">
                {orchestratorData.running ? 'Running' : 'Stopped'}
                {orchestratorData.queueSize > 0 && (
                  <span className="ml-1 text-yellow-400">
                    ({orchestratorData.queueSize} queued)
                  </span>
                )}
              </span>
            </div>
          )}

          {/* Running activities indicator */}
          {runningActivities.length > 0 && (
            <div className="flex items-center gap-1.5 text-blue-400">
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              <span>{runningActivities.length} operations</span>
            </div>
          )}

          {/* Gateway Monitor toggle */}
          <button
            onClick={() => setMonitorOpen(!monitorOpen)}
            className={`flex items-center gap-1.5 px-2 py-0.5 rounded transition-colors ${
              monitorOpen
                ? 'bg-primary-600/20 text-primary-400'
                : 'hover:bg-dark-800 text-dark-400 hover:text-dark-200'
            }`}
            title={monitorOpen ? 'Close Gateway Monitor' : 'Open Gateway Monitor'}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Monitor</span>
          </button>
        </div>

        <div className="flex items-center gap-3">
          {/* Environment badge - only show if not development */}
          {backendEnv && backendEnv !== 'development' && (
            <span
              className={`px-1.5 py-0.5 rounded text-[10px] font-medium uppercase ${
                backendEnv === 'production'
                  ? 'bg-green-900/50 text-green-400 border border-green-800/50'
                  : 'bg-yellow-900/50 text-yellow-400 border border-yellow-800/50'
              }`}
            >
              {backendEnv}
            </span>
          )}

          {/* Uptime indicator */}
          {backendUptime && (
            <span className="text-dark-500" title={`Backend uptime: ${backendUptime}`}>
              {backendUptime}
            </span>
          )}

          {/* Toggle button */}
          <button
            onClick={toggleStatusBar}
            className="flex items-center gap-1 px-2 py-0.5 hover:bg-dark-800 rounded text-dark-400 hover:text-dark-200"
            title={statusBarVisible ? 'Hide activity log' : 'Show activity log'}
          >
            {activities.length > 0 && (
              <span className="text-dark-500">{activities.length}</span>
            )}
            {statusBarVisible ? (
              <ChevronDown className="w-3.5 h-3.5" />
            ) : (
              <ChevronUp className="w-3.5 h-3.5" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
