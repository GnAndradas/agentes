import type { FastifyRequest, FastifyReply } from 'fastify';
import { z } from 'zod';
import { getServices } from '../../services/index.js';
import { toErrorResponse } from '../../utils/errors.js';
import {
  getAutonomyConfig,
  saveAutonomyConfig,
  loadAutonomyConfig,
} from '../../config/autonomy.js';
import { getTaskRouter, getFeedbackService } from '../../orchestrator/index.js';
import { getOpenClawAdapter } from '../../integrations/openclaw/index.js';
import { getSystemDiagnosticsService, getTaskTimelineService } from '../../system/index.js';
// NOTE: Gateway import kept ONLY for getDiagnostic() which needs full diagnostic object
// All other methods use the adapter
import { getGateway } from '../../openclaw/gateway.js';
import { getRuntimeInfo, getRuntimeSummary, checkEnvironment } from '../../utils/runtime.js';
import { getJobSafetyService } from '../../execution/JobSafetyService.js';
import { queryLogs, getErrorLogs, getRecentLogs } from '../../utils/dbLogger.js';

/**
 * Backend health check - includes runtime metadata for observability
 */
export async function health(_req: FastifyRequest, reply: FastifyReply) {
  const summary = getRuntimeSummary();
  return reply.send({
    status: 'ok',
    timestamp: Date.now(),
    ...summary,
  });
}

/**
 * Full runtime info - detailed system information
 * GET /api/system/runtime
 */
export async function runtimeInfo(_req: FastifyRequest, reply: FastifyReply) {
  try {
    const info = getRuntimeInfo();
    const envCheck = checkEnvironment();

    return reply.send({
      data: {
        ...info,
        environment: envCheck,
      },
    });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

/**
 * Environment check - detect runtime issues
 * GET /api/system/environment
 */
export async function environmentCheck(req: FastifyRequest, reply: FastifyReply) {
  try {
    const query = req.query as { refresh?: string };
    const forceRefresh = query.refresh === 'true';
    const envCheck = checkEnvironment(forceRefresh);

    return reply.send({ data: envCheck });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

/**
 * OpenClaw Gateway diagnostic - full connectivity test
 * Returns detailed status of REST API, Webhooks, Generation, and WebSocket
 */
export async function gatewayDiagnostic(_req: FastifyRequest, reply: FastifyReply) {
  try {
    const gateway = getGateway();
    const diagnostic = await gateway.getDiagnostic();

    return reply.send({
      data: diagnostic,
    });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

/**
 * Quick gateway status - for StatusBar polling
 *
 * HONEST: Uses getQuickStatus() which makes REAL requests.
 * Returns QuickStatus format that frontend expects (with probe, hooks.probed, etc.)
 */
export async function gatewayStatus(_req: FastifyRequest, reply: FastifyReply) {
  try {
    const gateway = getGateway();
    const status = await gateway.getQuickStatus();

    return reply.send({
      data: status,
    });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

export async function stats(_req: FastifyRequest, reply: FastifyReply) {
  try {
    const { agentService, taskService, generationService, approvalService } = getServices();
    const feedbackService = getFeedbackService();

    const [agents, tasks, generations, approvals, feedback] = await Promise.all([
      agentService.list(),
      taskService.list({ limit: 1000 }),
      generationService.list(),
      approvalService.list(),
      feedbackService.getAll(),
    ]);

    const agentStats = {
      total: agents.length,
      active: agents.filter(a => a.status === 'active').length,
      inactive: agents.filter(a => a.status === 'inactive').length,
      busy: agents.filter(a => a.status === 'busy').length,
      error: agents.filter(a => a.status === 'error').length,
    };

    // Separate parent tasks from subtasks
    const parentTasks = tasks.filter(t => !t.parentTaskId);
    const subtasks = tasks.filter(t => t.parentTaskId);
    const decomposedTasks = parentTasks.filter(t => t.metadata?._decomposed);

    const taskStats = {
      total: tasks.length,
      pending: tasks.filter(t => t.status === 'pending').length,
      queued: tasks.filter(t => t.status === 'queued').length,
      running: tasks.filter(t => t.status === 'running').length,
      completed: tasks.filter(t => t.status === 'completed').length,
      failed: tasks.filter(t => t.status === 'failed').length,
      // Additional metrics
      parentTasks: parentTasks.length,
      subtasks: subtasks.length,
      decomposed: decomposedTasks.length,
      subtasksCompleted: subtasks.filter(t => t.status === 'completed').length,
      subtasksFailed: subtasks.filter(t => t.status === 'failed').length,
    };

    const generationStats = {
      total: generations.length,
      pending: generations.filter(g => g.status === 'pending_approval').length,
      approved: generations.filter(g => g.status === 'approved' || g.status === 'active').length,
      rejected: generations.filter(g => g.status === 'rejected').length,
      active: generations.filter(g => g.status === 'active').length,
      failed: generations.filter(g => g.status === 'failed').length,
    };

    const approvalStats = {
      total: approvals.length,
      pending: approvals.filter(a => a.status === 'pending').length,
      approved: approvals.filter(a => a.status === 'approved').length,
      rejected: approvals.filter(a => a.status === 'rejected').length,
      expired: approvals.filter(a => a.status === 'expired').length,
    };

    const feedbackStats = {
      total: feedback.length,
      processed: feedback.filter(f => f.processed).length,
      unprocessed: feedback.filter(f => !f.processed).length,
      byType: {
        missingTool: feedback.filter(f => f.type === 'missing_tool').length,
        missingSkill: feedback.filter(f => f.type === 'missing_skill').length,
        missingCapability: feedback.filter(f => f.type === 'missing_capability').length,
        blocked: feedback.filter(f => f.type === 'blocked').length,
      },
    };

    // Get orchestrator status
    const taskRouter = getTaskRouter();
    const orchestratorStatus = taskRouter.getStatus();

    // Get gateway status via adapter
    const adapter = getOpenClawAdapter();

    return reply.send({
      agents: agentStats,
      tasks: taskStats,
      generations: generationStats,
      approvals: approvalStats,
      feedback: feedbackStats,
      orchestrator: {
        running: orchestratorStatus.running,
        queueSize: orchestratorStatus.queueSize,
        processing: orchestratorStatus.processing,
        sequentialMode: orchestratorStatus.sequentialMode,
      },
      gateway: {
        restConnected: adapter.isConnected(),
        wsConnected: adapter.isWsConnected(),
      },
      system: {
        uptime: process.uptime() * 1000,
        memoryUsage: process.memoryUsage().heapUsed / 1024 / 1024,
      },
    });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

export async function events(req: FastifyRequest, reply: FastifyReply) {
  try {
    const query = req.query as { limit?: string; category?: string };
    const { eventService } = getServices();
    const data = await eventService.list({
      limit: query.limit ? parseInt(query.limit, 10) : 50,
      category: query.category,
    });
    return reply.send({ data });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

// Autonomy config schema
const UpdateAutonomySchema = z.object({
  level: z.enum(['manual', 'supervised', 'autonomous']).optional(),
  canCreateAgents: z.boolean().optional(),
  canGenerateSkills: z.boolean().optional(),
  canGenerateTools: z.boolean().optional(),
  requireApprovalFor: z.object({
    taskExecution: z.enum(['none', 'high_priority', 'all']).optional(),
    agentCreation: z.boolean().optional(),
    skillGeneration: z.boolean().optional(),
    toolGeneration: z.boolean().optional(),
  }).optional(),
  humanTimeout: z.number().positive().optional(),
  fallbackBehavior: z.enum(['pause', 'reject', 'auto_approve']).optional(),
  sequentialExecution: z.boolean().optional(),
});

export async function getAutonomy(_req: FastifyRequest, reply: FastifyReply) {
  try {
    const config = await loadAutonomyConfig();
    const taskRouter = getTaskRouter();
    const routerStatus = taskRouter.getStatus();

    return reply.send({
      data: {
        ...config,
        orchestrator: {
          running: routerStatus.running,
          queueSize: routerStatus.queueSize,
          processing: routerStatus.processing,
        },
      },
    });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

export async function updateAutonomy(req: FastifyRequest, reply: FastifyReply) {
  try {
    const parsed = UpdateAutonomySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation failed', details: parsed.error.flatten() });
    }

    const updated = await saveAutonomyConfig(parsed.data);

    // Apply sequential mode to TaskRouter
    const taskRouter = getTaskRouter();
    taskRouter.setSequentialMode(updated.sequentialExecution);

    return reply.send({ data: updated });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

export async function getOrchestratorStatus(_req: FastifyRequest, reply: FastifyReply) {
  try {
    const taskRouter = getTaskRouter();
    const status = taskRouter.getStatus();
    const autonomy = getAutonomyConfig();

    return reply.send({
      data: {
        ...status,
        autonomyLevel: autonomy.level,
      },
    });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

// =============================================================================
// SYSTEM DIAGNOSTICS
// =============================================================================

/**
 * GET /api/system/diagnostics
 * Full system health diagnostics
 */
export async function systemDiagnostics(_req: FastifyRequest, reply: FastifyReply) {
  try {
    const diagnostics = getSystemDiagnosticsService();
    const result = await diagnostics.getSystemHealth();
    return reply.send({ data: result });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

/**
 * GET /api/system/readiness
 * Production readiness report
 */
export async function systemReadiness(_req: FastifyRequest, reply: FastifyReply) {
  try {
    const diagnostics = getSystemDiagnosticsService();
    const result = await diagnostics.getReadinessReport();
    return reply.send({ data: result });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

/**
 * GET /api/system/issues
 * Get only critical issues and warnings
 */
export async function systemIssues(_req: FastifyRequest, reply: FastifyReply) {
  try {
    const diagnostics = getSystemDiagnosticsService();
    const [critical, warnings] = await Promise.all([
      diagnostics.getCriticalIssues(),
      diagnostics.getWarnings(),
    ]);
    return reply.send({
      data: {
        critical,
        warnings,
        totalCritical: critical.length,
        totalWarnings: warnings.length,
      },
    });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

/**
 * GET /api/system/metrics
 * Current system metrics snapshot
 */
export async function systemMetrics(_req: FastifyRequest, reply: FastifyReply) {
  try {
    const diagnostics = getSystemDiagnosticsService();
    const result = await diagnostics.getMetrics();
    return reply.send({ data: result });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

// =============================================================================
// TASK TIMELINE & OBSERVABILITY
// =============================================================================

/**
 * GET /api/system/overview
 * Comprehensive system overview with problem detection
 */
export async function systemOverview(_req: FastifyRequest, reply: FastifyReply) {
  try {
    const timeline = getTaskTimelineService();
    const result = await timeline.getSystemOverview();
    return reply.send({ data: result });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

/**
 * GET /api/system/tasks/:taskId/timeline
 * Get complete timeline for a specific task
 */
export async function taskTimeline(req: FastifyRequest, reply: FastifyReply) {
  try {
    const { taskId } = req.params as { taskId: string };
    const timeline = getTaskTimelineService();
    const result = await timeline.getTaskTimeline(taskId);

    if (!result) {
      return reply.status(404).send({ error: 'Task not found' });
    }

    return reply.send({ data: result });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

/**
 * GET /api/system/problems/stuck
 * Get all stuck tasks
 */
export async function stuckTasks(_req: FastifyRequest, reply: FastifyReply) {
  try {
    const timeline = getTaskTimelineService();
    const result = await timeline.getStuckTasks();
    return reply.send({
      data: result,
      count: result.length,
    });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

/**
 * GET /api/system/problems/high-retry
 * Get tasks with high retry counts
 */
export async function highRetryTasks(_req: FastifyRequest, reply: FastifyReply) {
  try {
    const timeline = getTaskTimelineService();
    const result = await timeline.getHighRetryTasks();
    return reply.send({
      data: result,
      count: result.length,
    });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

/**
 * GET /api/system/problems/blocked
 * Get blocked tasks
 */
export async function blockedTasks(_req: FastifyRequest, reply: FastifyReply) {
  try {
    const timeline = getTaskTimelineService();
    const result = await timeline.getBlockedTasks();
    return reply.send({
      data: result,
      count: result.length,
    });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

/**
 * GET /api/system/problems
 * Get all problem tasks combined
 */
export async function allProblems(_req: FastifyRequest, reply: FastifyReply) {
  try {
    const timeline = getTaskTimelineService();
    const [stuck, highRetry, blocked] = await Promise.all([
      timeline.getStuckTasks(),
      timeline.getHighRetryTasks(),
      timeline.getBlockedTasks(),
    ]);

    return reply.send({
      data: {
        stuck,
        highRetry,
        blocked,
      },
      counts: {
        stuck: stuck.length,
        highRetry: highRetry.length,
        blocked: blocked.length,
        total: stuck.length + highRetry.length + blocked.length,
      },
    });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

// =============================================================================
// SAFETY & LOGS (Production Hardening)
// =============================================================================

/**
 * GET /api/system/safety
 * Job safety status (failsafe, retries, whitelist)
 */
export async function getSafetyStatus(_req: FastifyRequest, reply: FastifyReply) {
  try {
    const safety = getJobSafetyService();
    const failsafe = safety.getFailsafeState();
    const whitelist = safety.getWhitelist();

    return reply.send({
      data: {
        failsafe: {
          active: failsafe.active,
          reason: failsafe.reason,
          activatedAt: failsafe.activatedAt,
          consecutiveFailures: failsafe.consecutiveFailures,
        },
        toolWhitelist: {
          enabled: whitelist.length > 0,
          tools: whitelist,
        },
      },
    });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

/**
 * POST /api/system/safety/failsafe/deactivate
 * Manually deactivate failsafe mode
 */
export async function deactivateFailsafe(_req: FastifyRequest, reply: FastifyReply) {
  try {
    const safety = getJobSafetyService();
    safety.deactivateFailsafe();
    return reply.send({ data: { deactivated: true } });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

/**
 * GET /api/system/logs
 * Query system logs
 */
export async function getLogs(req: FastifyRequest, reply: FastifyReply) {
  try {
    const query = req.query as {
      level?: string;
      source?: string;
      jobId?: string;
      limit?: string;
    };

    const logs = queryLogs({
      level: query.level as 'debug' | 'info' | 'warn' | 'error' | 'fatal' | undefined,
      source: query.source,
      jobId: query.jobId,
      limit: query.limit ? parseInt(query.limit, 10) : 100,
    });

    return reply.send({
      data: logs,
      count: logs.length,
    });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

/**
 * GET /api/system/logs/errors
 * Get recent error logs
 */
export async function getLogsErrors(req: FastifyRequest, reply: FastifyReply) {
  try {
    const query = req.query as { limit?: string };
    const logs = getErrorLogs(query.limit ? parseInt(query.limit, 10) : 50);

    return reply.send({
      data: logs,
      count: logs.length,
    });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}

/**
 * GET /api/system/logs/recent
 * Get recent logs (last N minutes)
 */
export async function getLogsRecent(req: FastifyRequest, reply: FastifyReply) {
  try {
    const query = req.query as { minutes?: string; limit?: string };
    const logs = getRecentLogs(
      query.minutes ? parseInt(query.minutes, 10) : 60,
      query.limit ? parseInt(query.limit, 10) : 200
    );

    return reply.send({
      data: logs,
      count: logs.length,
    });
  } catch (err) {
    const { statusCode, body } = toErrorResponse(err);
    return reply.status(statusCode).send(body);
  }
}
